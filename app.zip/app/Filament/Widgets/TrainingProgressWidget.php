<?php

namespace App\Filament\Widgets;

use App\Models\StaffTraining;
use Filament\Widgets\Widget;
use Illuminate\Support\Facades\Auth;

class TrainingProgressWidget extends Widget
{
    protected static ?int $sort = 4;

    protected int | string | array $columnSpan = 2;

    protected string $view = 'filament.widgets.training-progress-widget';

    public function getViewData(): array
    {
        $user = Auth::user();

        $total_hours = $user->staff->training()
            ->whereYear('training_date', now()->year)
            ->where('is_verified', 1)
            ->sum('duration');

        $target = setting('training_hours_per_year');
        $percentage = min(100, ($total_hours / $target) * 100);

        return [
            'total_hours' => $total_hours,
            'target' => $target,
            'percentage' => $percentage,
        ];
    }
}
