<div class="flex flex-col h-[80vh]">
    <div class="flex-1 w-full bg-gray-100 rounded-lg overflow-hidden relative">
        <!--[if BLOCK]><![endif]--><?php if(!empty($url)): ?>
            <iframe src="<?php echo e($url); ?>" class="w-full h-full" frameborder="0"></iframe>
        <?php else: ?>
            <div class="flex items-center justify-center h-full text-gray-500">
                File tidak ditemukan.
            </div>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
    </div>
</div><?php /**PATH C:\Users\tamam\Herd\simpeg\resources\views/filament/components/preview-pdf-2.blade.php ENDPATH**/ ?>