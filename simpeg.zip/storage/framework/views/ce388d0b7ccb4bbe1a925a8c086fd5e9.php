<?php
$presence = \App\Models\Presence::where('staff_id', Auth::user()->staff_id)->whereDate('presence_date', now()->toDateString())->whereNull('check_out')->count() > 0;
?>
<div 
x-data="{
    lat: null,
    lng: null,
    radius: Infinity,
    canCheckIn: false,
    loading: false,
    mapLoaded: false,

    isFakeDetected: false,
    fakeMessage: '',
    lastUpdateTime: 0,   // Waktu terakhir data masuk (Heartbeat)
    lastMoveTime: 0,     // Waktu terakhir koordinat berubah (Jitter)
    lastLat: 0,
    lastLng: 0,
    gpsAccuracy: 0,
    checkInterval: null,

    mode: '<?php echo e($presence ? "check-out" : "check-in"); ?>',
    getModalId() {
        const modal = document.querySelector(`[id^='fi-'][id$='-action-0']`);
        return modal.id;
    },

    getMap() {
        if (!this.lat || !this.lng) return '';
        this.mapLoaded = false;
        return `https://www.google.com/maps?q=${this.lat},${this.lng}&hl=es;z=17&output=embed`;
        
    },

    // Helper Hitung Jarak (Haversine Simpel) untuk deteksi Jitter
    getDist(lat1, lon1, lat2, lon2) {
        if (lat1 == 0) return 100; 
        var p = 0.017453292519943295;    
        var c = Math.cos;
        var a = 0.5 - c((lat2 - lat1) * p)/2 + 
                c(lat1 * p) * c(lat2 * p) * (1 - c((lon2 - lon1) * p))/2;
        return 12742 * Math.asin(Math.sqrt(a)) * 1000; // Meter
    },

    async submitCheckIn() {
        if (!this.canCheckIn || this.isFakeDetected) return;

        this.loading = true;
        console.log('🚀 Memulai proses Submit Check-in...');

        try {
            // Contoh: kirim data ke backend
            const response = await fetch('/check-in-by-gps', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': document.querySelector('meta[name=csrf-token]').content
                },
                body: JSON.stringify({
                    lat: this.lat,
                    lng: this.lng,
                    radius: this.radius,
                    mode: this.mode
                })
            });

            const json = await response.json();
            console.log('✅ Response Server:', json);

            if (json.status === 'ok') {
                $wire.dispatch('close-modal', { id:this.getModalId() });
            }
        } catch (err) {
            console.error(err);
            alert('Terjadi kesalahan sistem.');
        }
        this.loading = false;
    }
}
" x-init="
    async () => {
        try {
            console.clear();
            console.log('%c🏁 SYSTEM START: Inisialisasi GPS...', 'background:blue; color:white; padding:4px;');

            loading = true;

            isFakeDetected = false;
            
            // Reset Timer
            lastUpdateTime = 0;
            lastMoveTime = Date.now();

            let bestPosition = null;
            let attempts = 0;

            let previousLat = null;
            let previousLng = null;

            const MIN_SAMPLES_REQUIRED = 4;

            // --- (HEARTBEAT MONITOR) ---
            if (checkInterval) clearInterval(checkInterval);
            
            checkInterval = setInterval(() => {
                // Jangan cek jika belum dapat data pertama (Cold Start)
                if (lastUpdateTime === 0) {
                    console.log('⏳ Menunggu data GPS pertama masuk...');
                    return;
                }

                const now = Date.now();
                
                // Adaptive Timeout: 
                // Jika Akurasi Bagus (<20m), batas diam 20 detik.
                // Jika Akurasi Buruk (>20m), batas diam 120 detik (Network location memang lambat).
                let timeoutLimit = (gpsAccuracy < 20) ? 20000 : 120000;

                console.log(`👮 Polisi Tidur Check | Hening: ${now - lastUpdateTime}ms | Batas: ${timeoutLimit}ms | Akurasi Terakhir: ${gpsAccuracy}m`);

                // Cek 1: Heartbeat Mati (Tidak ada update sama sekali)
                if ((now - lastUpdateTime) > timeoutLimit) {
                    // Hanya vonis jika akurasi bagus (karena GPS asli harusnya cepat)
                    if (gpsAccuracy < 50) {
                        console.error('%c⚠️ ALARM: GPS BEKU DETECTED!', 'font-size:16px; color:red;');
                        isFakeDetected = true;
                        fakeMessage = 'Sinyal GPS Beku (Indikasi Fake GPS). Silakan refresh.';
                        loading = false;
                        navigator.geolocation.clearWatch(watcher);
                        clearInterval(checkInterval);
                    } else {
                        console.warn('⚠️ Sinyal lemah/hilang, tapi diabaikan karena akurasi buruk.');
                    }
                }

                // Cek 2: Jitter Mati (Akurasi Tinggi TAPI Koordinat Tidak Geser > 0.5m)
                // Ini menangkap Fake GPS yang 'mengirim data' tapi koordinatnya di-lock.
                if (gpsAccuracy < 20 && (now - lastMoveTime > 30000)) {
                    console.error('%c⚠️ ALARM: LOKASI STATIS TIDAK WAJAR!', 'font-size:16px; color:red;');
                    isFakeDetected = true;
                    fakeMessage = 'Lokasi Statis Tidak Wajar. Matikan Fake GPS.';
                    loading = false;
                    navigator.geolocation.clearWatch(watcher);
                    clearInterval(checkInterval);
                }

            }, 2000); // Cek setiap 2 detik

            const watcher = navigator.geolocation.watchPosition(
                async (pos) => {
                    const now = Date.now();
                    
                    console.group(`📡 DATA MASUK #${attempts + 1}`);
                    console.log(`Lat: ${pos.coords.latitude}, Lng: ${pos.coords.longitude}`);
                    console.log(`Akurasi: ${pos.coords.accuracy} meter`);

                    if (previousLat !== null) {
                        const jumpDist = getDist(previousLat, previousLng, pos.coords.latitude, pos.coords.longitude);
                        console.log(`🏃 Jarak lompatan: ${jumpDist.toFixed(2)} meter`);

                        if (jumpDist > 2000) { 
                            console.error('%c⚠️ ALARM: TELEPORTASI DETECTED!', 'font-size:16px; color:red;');
                            console.error(`User pindah ${jumpDist.toFixed(0)}m dalam sekejap. Mustahil.`);
                            
                            isFakeDetected = true;
                            fakeMessage = 'Terdeteksi manipulasi lokasi (Lompatan tidak wajar).';
                            loading = false;
                            navigator.geolocation.clearWatch(watcher);
                            clearInterval(checkInterval);
                            return; // Stop eksekusi
                        }
                    }
                    // Simpan posisi ini untuk perbandingan data berikutnya
                    // KITA SIMPAN BAHKAN DATA YANG AKURASINYA BURUK
                    // Agar kalau dia loncat dari Fake -> Asli (Jelek), kita tetap tangkap.
                    previousLat = pos.coords.latitude;
                    previousLng = pos.coords.longitude;

                    // Update Heartbeat
                    lastUpdateTime = now;
                    gpsAccuracy = pos.coords.accuracy;
                    attempts++;

                    // Logika Jitter: Hitung jarak dari posisi terakhir tercatat
                    const dist = getDist(lastLat, lastLng, pos.coords.latitude, pos.coords.longitude);
                    console.log(`📏 Perpindahan dari data valid terakhir: ${dist.toFixed(4)} meter`);
                    
                    // Jika pindah > 0.5 meter, anggap bergerak (Reset timer beku)
                    if (dist > 0.5) {
                        console.log('✅ User Bergerak (Reset Timer Statis)');
                        lastMoveTime = now;
                        lastLat = pos.coords.latitude;
                        lastLng = pos.coords.longitude;
                    } else {
                        console.log('⛔ User Diam / Windows Lag (Timer Statis Jalan Terus)');
                    }

                    // Ambil posisi terbaik (akurasinya kecil = akurat)
                    if (
                        !bestPosition ||
                        pos.coords.accuracy < bestPosition.coords.accuracy
                    ) {
                        console.log('⭐ Posisi Terbaik Diupdate!');
                        bestPosition = pos;
                    }

                    const isAccurateEnough = bestPosition.coords.accuracy < 40;
                    const hasEnoughSamples = attempts >= MIN_SAMPLES_REQUIRED;
                    const isTimeOut = attempts >= 5;

                    // Jika akurasi sudah sangat bagus (< 40 m) ATAU sudah 3 kali percobaan
                    if ((isAccurateEnough && hasEnoughSamples) || isTimeOut) {
                        if (isFakeDetected) return;

                        console.log('%c🎯 GPS LOCKED! Mematikan Watcher & Mengirim ke Server...', 'background:green; color:white;');
                        navigator.geolocation.clearWatch(watcher);
                        clearInterval(checkInterval);
                        loading = false;

                        console.time('ServerResponseTime');
                        // Kirim radius check ke server
                        const loc = await fetch('/check-radius', {
                            method: 'POST',
                            headers: {
                                'Content-Type': 'application/json'
                            },
                            body: JSON.stringify({
                                lat: bestPosition.coords.latitude,
                                lng: bestPosition.coords.longitude,
                            })
                        });

                        console.timeEnd('ServerResponseTime');
                        const json = await loc.json();
                        console.log('📩 Data dari Server:', json);

                        // Update variabel Alpine
                        radius = json.radius;
                        canCheckIn = (json.radius <= 100) && !isFakeDetected;
                        lat = json.user_lat;
                        lng = json.user_lng;

                        return;
                    } else {
                        console.log('⏳ Belum memenuhi syarat akurasi atau jumlah attempt...');
                    }
                },
                (err) => {
                    if (lat && lng && err.code === 2) {
                        console.warn('GPS Glitch diabaikan');
                        return;
                    }
                    console.error('GPS Error:', err);
                    loading = false;
                    isFakeDetected = true; 
                    fakeMessage = 'Gagal mengambil lokasi: ' + err.message;
                    clearInterval(checkInterval);
                },
                {
                    enableHighAccuracy: true,
                    maximumAge: 10000,
                    timeout: 20000
                }
            );
        } catch (err) {
            console.error('Gagal mendapatkan data perangkat:', err);
        }
}
" class="relative space-y-4">

    <div x-show="isFakeDetected" class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative">
        <strong class="font-bold">Error!</strong>
        <span class="block sm:inline" x-text="fakeMessage"></span>
    </div>

    
    <div 
        x-show="!mapLoaded"
        x-transition.opacity
        class="absolute inset-0 z-10 flex items-center justify-center bg-gray-100 overflow-hidden rounded-xl h-60"
    >
        <!-- Skeleton Shimmer -->
        <div class="absolute inset-0 bg-linear-to-r from-gray-200 via-gray-300 to-gray-200 animate-shimmer"></div>

        <!-- Spinner -->
        <div class="relative z-20">
            <div class="h-10 w-10 border-4 border-gray-300 border-t-blue-600 rounded-full animate-spin"></div>
        </div>
    </div>

    <iframe
        x-show="!isFakeDetected && lat"
        x-bind:src="getMap()"
        @load="mapLoaded = true"
        width="100%"
        height="240"
        class="rounded-xl border"
        allowfullscreen=""
        loading="lazy">
    </iframe>

    <style>
    @keyframes shimmer {
        0% { transform: translateX(-100%); }
        100% { transform: translateX(100%); }
    }
    .animate-shimmer {
        animation: shimmer 2.2s infinite linear;
    }
    </style>

    <div class="flex flex-col md:flex-row items-center justify-between">
        
        <div class="text-sm mb-4 md:mb-0 w-full md:w-auto">
            <div class="text-left">
                <strong>Latitude:</strong>
                <span x-text="lat ?? 'Mendeteksi...'"></span>
            </div>
            <div class="text-left">
                <strong>Longitude:</strong>
                <span x-text="lng ?? 'Mendeteksi...'"></span>
            </div>
            <div class="text-left">
                <strong>Radius:</strong>
                <span x-text="radius != Infinity ? radius.toFixed(2) + ' meter' : 'Mendeteksi...'"></span>
            </div>
        </div>

        
        <div class="text-right w-full md:w-auto">
            <button
                x-bind:disabled="!canCheckIn || isFakeDetected"
                @click="submitCheckIn"
                class="px-4 py-2 rounded-lg text-white flex items-center justify-center gap-2 w-full md:w-auto"
                :class="(canCheckIn && !isFakeDetected) ? 'bg-emerald-600 hover:bg-emerald-700' : 'bg-gray-400 cursor-not-allowed'">
                <?php if (isset($component)) { $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c = $attributes; } ?>
<?php $component = BladeUI\Icons\Components\Svg::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('heroicon-o-finger-print'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\BladeUI\Icons\Components\Svg::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-5 h-5']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $attributes = $__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $component = $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?>
                <!--[if BLOCK]><![endif]--><?php if($presence): ?>
                    Check-Out
                <?php else: ?>
                    Check-In
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            </button>
        </div>
    </div>

</div>
<?php /**PATH C:\Users\tamam\Herd\simpeg\resources\views/filament/components/map-modal.blade.php ENDPATH**/ ?>