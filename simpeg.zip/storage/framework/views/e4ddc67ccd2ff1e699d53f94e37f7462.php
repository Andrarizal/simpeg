<?php if (isset($component)) { $__componentOriginalb525200bfa976483b4eaa0b7685c6e24 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb525200bfa976483b4eaa0b7685c6e24 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament-widgets::components.widget','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament-widgets::widget'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php if (isset($component)) { $__componentOriginalee08b1367eba38734199cf7829b1d1e9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalee08b1367eba38734199cf7829b1d1e9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament::components.section.index','data' => ['class' => 'bg-emerald-400 dark:bg-emerald-600']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament::section'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'bg-emerald-400 dark:bg-emerald-600']); ?>
        
        <div class="md:grid md:grid-cols-12 md:gap-6">
            <div class="md:col-span-2 flex justify-center md:justify-end items-center min-w-full">
                <?php
                $avatarUrl = $user->getFilamentAvatarUrl();
                $initials = collect(explode(' ', $user->name))
                    ->map(fn ($word) => mb_substr($word, 0, 1))
                    ->join('');
                ?>
                <!--[if BLOCK]><![endif]--><?php if($avatarUrl): ?>
                    <img 
                        src="<?php echo e($avatarUrl); ?>" 
                        alt="<?php echo e($user->name); ?>" 
                        class="object-cover rounded-full w-24 h-24"
                    />
                <?php else: ?>
                    <span class="text-2xl font-semibold text-gray-300 dark:text-gray-700 bg-amber-950 p-6 py-7 rounded-full">
                        <?php echo e(substr(strtoupper($initials), 0, 2)); ?>

                    </span>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            </div>
            <div class="my-4 md:col-span-6">
                <p class="text-center md:text-left font-semibold text-gray-600 dark:text-gray-300 text-sm"><?php echo e($user->staff->nip); ?></p>
                <h3 class="text-center md:text-left text-2xl font-semibold"><?php echo e($user->name); ?></h3>
                <p class="text-center md:text-left text-gray-600 dark:text-gray-300 text-sm">Jabatan: <?php echo e($user->staff->chair->name); ?></p>
                <p class="text-center md:text-left text-gray-600 dark:text-gray-300 text-sm">Unit Kerja:    <?php echo e($user->staff->unit->name); ?></p>
            </div>
            <div class="md:col-span-4 flex justify-around items-center md:gap-4">
                <div class="bg-gray-50 dark:bg-gray-800 p-4 rounded-lg shadow-sm w-32 text-center">
                    <p class="text-sm text-gray-500 dark:text-gray-400">Masa Kerja</p>
                    <p class="text-3xl font-semibold text-gray-800 dark:text-gray-100">
                        <?php echo e($masaKerja); ?>

                    </p>
                    <p class="text-xs text-gray-500 dark:text-gray-400">tahun</p>
                </div>
                <div class="bg-gray-50 dark:bg-gray-800 p-4 rounded-lg shadow-sm w-32 text-center">
                    <p class="text-sm text-gray-500 dark:text-gray-400">Pensiun</p>
                    <p class="text-3xl font-semibold text-gray-800 dark:text-gray-100">
                        <?php echo e($countdownPensiun); ?>

                    </p>
                    <p class="text-xs text-gray-500 dark:text-gray-400">tahun lagi</p>
                </div>
            </div>
        </div>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalee08b1367eba38734199cf7829b1d1e9)): ?>
<?php $attributes = $__attributesOriginalee08b1367eba38734199cf7829b1d1e9; ?>
<?php unset($__attributesOriginalee08b1367eba38734199cf7829b1d1e9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalee08b1367eba38734199cf7829b1d1e9)): ?>
<?php $component = $__componentOriginalee08b1367eba38734199cf7829b1d1e9; ?>
<?php unset($__componentOriginalee08b1367eba38734199cf7829b1d1e9); ?>
<?php endif; ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb525200bfa976483b4eaa0b7685c6e24)): ?>
<?php $attributes = $__attributesOriginalb525200bfa976483b4eaa0b7685c6e24; ?>
<?php unset($__attributesOriginalb525200bfa976483b4eaa0b7685c6e24); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb525200bfa976483b4eaa0b7685c6e24)): ?>
<?php $component = $__componentOriginalb525200bfa976483b4eaa0b7685c6e24; ?>
<?php unset($__componentOriginalb525200bfa976483b4eaa0b7685c6e24); ?>
<?php endif; ?>
<?php /**PATH C:\Users\tamam\Herd\simpeg\resources\views/filament/widgets/welcome-message.blade.php ENDPATH**/ ?>