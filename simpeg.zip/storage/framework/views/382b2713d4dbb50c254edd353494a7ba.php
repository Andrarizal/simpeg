  <div class="flex w-full px-6 lg:px-18">
      <form wire:submit="authenticate" class="space-y-4 w-full self-center">
          <div class="flex justify-center lg:justify-start items-center gap-4 pb-4">
            <img src="<?php echo e(asset('img/rsumpyk.png')); ?>" class="w-14 h-14">
            <h1 class="font-semibold leading-tight lg:text-xl hidden lg:block">Sistem Informasi Manajemen dan <br>Tenaga Pegawai</h1>
            <h1 class="font-semibold leading-tight text-2xl lg:hidden">SIMANTAP</h1>
          </div>
          <?php echo e($this->form); ?>


          <div class="mt-4 space-y-4">
            <?php if (isset($component)) { $__componentOriginal6330f08526bbb3ce2a0da37da512a11f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6330f08526bbb3ce2a0da37da512a11f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament::components.button.index','data' => ['type' => 'submit','class' => 'w-full']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament::button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'submit','class' => 'w-full']); ?>
              Login
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6330f08526bbb3ce2a0da37da512a11f)): ?>
<?php $attributes = $__attributesOriginal6330f08526bbb3ce2a0da37da512a11f; ?>
<?php unset($__attributesOriginal6330f08526bbb3ce2a0da37da512a11f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6330f08526bbb3ce2a0da37da512a11f)): ?>
<?php $component = $__componentOriginal6330f08526bbb3ce2a0da37da512a11f; ?>
<?php unset($__componentOriginal6330f08526bbb3ce2a0da37da512a11f); ?>
<?php endif; ?>
            <div class="text-center lg:text-left">
              <span class="text-sm text-gray-500">Belum punya akun?</span>
              <a href="<?php echo e(\App\Filament\Pages\PreRegistration::getUrl()); ?>"
                class="text-sm text-primary-600 font-semibold hover:underline">
                Register
              </a>
          </div>
        </div>
      </form>
    </div>
<?php /**PATH C:\Users\tamam\Herd\simpeg\resources\views/filament/pages/login.blade.php ENDPATH**/ ?>