<div class="fi-topbar-start flex items-center gap-2">
    
    <img src="<?php echo e(asset('img/rsumpyk.png')); ?>" class="h-10" alt="Logo">

    
    <span class="font-bold text-lg tracking-wide">
        <?php echo e(config('app.name', 'My App')); ?>

    </span>
</div>
<?php /**PATH C:\Users\tamam\Herd\simpeg\resources\views/filament/schemas/components/brand-logo.blade.php ENDPATH**/ ?>