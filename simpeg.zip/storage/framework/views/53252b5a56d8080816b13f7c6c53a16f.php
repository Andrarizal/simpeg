<div class="flex w-full">
    <form wire:submit="preRegist" class="space-y-4 w-full self-center">
        <?php echo e($this->form); ?>

        
    </form>
</div><?php /**PATH C:\Users\tamam\Herd\simpeg\resources\views/filament/pages/re-registration.blade.php ENDPATH**/ ?>