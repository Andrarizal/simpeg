<div class="fi-topbar-start flex items-center gap-2">
    {{-- Logo --}}
    <img src="{{ asset('img/rsumpyk.png') }}" class="h-10" alt="Logo">

    {{-- Brand Name --}}
    <span class="font-bold text-lg tracking-wide">
        {{ config('app.name', 'My App') }}
    </span>
</div>
