<x-filament::section>
    <h2>Daftar Persetujuan Cuti</h2>
    <p>Konten khusus tab Persetujuan bisa ditaruh di sini.</p>
</x-filament::section>