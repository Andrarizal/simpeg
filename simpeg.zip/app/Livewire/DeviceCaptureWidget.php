<?php

namespace App\Livewire;

use Filament\Widgets\Widget;

class DeviceCaptureWidget extends Widget
{
    protected string $view = 'livewire.device-capture-widget';
}
